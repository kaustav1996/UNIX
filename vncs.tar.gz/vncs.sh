#!/bin/bash
OS=$(lsb_release -si); #getting os details
VR=$(lsb_release -sr);
if [[ "$OS" == "Ubuntu" ]]; then
	echo -e "123\n123" | sudo passwd  root ; #changing password
	sudo apt-get update;
	sudo apt-get -y install chromium-browser browser-plugin-freshplayer-pepperflash firefox vnc4server autocutsel;
	sudo apt-get -y install xfce4 xfce4-goodies;
	wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -O /tmp/google-chrome-stable_current_amd64.deb;
	sudo dpkg -i /tmp/google-chrome-stable_current_amd64.deb;sudo apt-get -y install -f; #installing chrome
	rm /tmp/google-chrome-stable_current_amd64.deb;
	sudo chmod a=rwx /etc/chromium-browser/default;
	sudo chmod -R a=rwx /etc/xdg/autostart/ ; #granting permission to edit autostart
	sudo chmod -R a=rwx /home/;
	echo "CHROMIUM_FLAGS=\" --user-data-dir --no-sandbox\"" >  /etc/chromium-browser/default ;
	echo -e "[Desktop Entry]\nName=chrome\nExec=google-chrome --no-sandbox www.gmail.com\nType=Application" >> /home/chrome.desktop
	echo -e "[Desktop Entry]\nName=chromium\nExec=chromium-browser www.gmail.com\nType=Application" >> /home/chromium.desktop
	echo -e "[Desktop Entry]\nName=firefox\nExec=firefox www.gmail.com\nType=Application" >> /home/firefox.desktop
	chmod +x /home/chromium.desktop;
	chmod +x /home/chrome.desktop;
	chmod +x /home/firefox.desktop;
	echo -e "[Desktop Entry]\nName=Terminal_autostart\nExec=xterm\nType=Application" >>/etc/xdg/autostart/term.desktop; #terminal would start at start up
	sudo chmod +x /etc/xdg/autostart/term.desktop;
	echo -e "[Desktop Entry]\nName=Chrome_autostart\nExec=google-chrome --no-sandbox www.gmail.com\nType=Application" >>/etc/xdg/autostart/chrome.desktop; #chrome would start at start up
	sudo chmod +x /etc/xdg/autostart/chrome.desktop;
	echo -e "12345678\n12345678" | sudo vncserver -geometry 1600x900 -depth 24; 
	sudo sed -i.bak '/x-terminal-emulator/c startxfce4 & \n' ~/.vnc/xstartup;
	sudo vncserver -kill :1;
	sudo vncserver -geometry 1600x900 -depth 24;
	alias extip='dig +short myip.opendns.com @resolver1.opendns.com';
	city=$(curl ipinfo.io/city/$extip);
	region=$(curl ipinfo.io/region/$extip);
	country=$(curl ipinfo.io/country/$extip);
	latlong=$(curl ipinfo.io/loc/$extip);
	echo "Internal IP: ";
	ip addr | grep 'state UP' -A2 | tail -n1 | awk '{print $2}' | cut -f1  -d'/';
	echo "External IP: ";
	dig +short myip.opendns.com @resolver1.opendns.com;
	echo "Operating System: " $OS $VR;
	
	echo "Location : " $city " , " $region " , " $country " . Latitude , Longitude --> " $latlong;
else
	echo "Error!! Operating System Not Supported";
fi
